







void compress();
int read_option();
void fist();

void otherLine_Horintal();
void chosee(int option);
void inOrder(struct tree* source);
void PosOrder(struct tree* source);
void Pre_Order(struct tree* source);
void show_leves_tree(struct tree* source);
void CustINorder(struct tree* source, int *counter);
void cust_path_BFS( struct tree* source, int *counter);
void calcular_preOrdem_cust(struct tree* source, int *counter);
void cust_PosOrdem(struct tree* source, int *counter);