
@Autor : Yuri Domingos E1000021711
Data   : 23 -10 -2020
UCAN   : Universidade Católica de Angola

1.1

   Como rodar o programa ?
   
    O programa foi construido em módolos, para melhor realizar a implementação, toda via para rodar num sistema operativo GNU/LINUX simplesmente digite os passos abaixo. 
    
    1 . digite o comando gcc -c functions.c
    2.  digite o comando gcc -c Transversal_operations.c
    3.  digite o comando gcc -c Main_Function.c
    
    4 digite o comando gcc -o runnerFile.exe functions.o  Transversal_operations.o  Main_Function.o
    5 digite o comando ./runnerFile.exe
